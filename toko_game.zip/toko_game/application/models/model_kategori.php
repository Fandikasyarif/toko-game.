<?php

class Model_kategori extends CI_Model{
    
    public function data_mobilelegends(){
        return $this->db->get_where("tb_barang",array('kategori' => 'mobile_legends'));
    }

    public function data_freefire(){
        return $this->db->get_where("tb_barang",array('kategori' => 'freefire'));
    }

    public function data_pubg(){
        return $this->db->get_where("tb_barang",array('kategori' => 'pubg'));
    }
}