<?php
class Kategori extends CI_Controller
{

    public function mobilelegends()
    {

        $data['mobilelegends'] = $this->model_kategori->data_mobilelegends()->result();

        $this->load->view('templates/header');
        $this->load->view('templates/sidebar');
        $this->load->view('mobilelegends', $data);
        $this->load->view('templates/footer');
    }

    public function freefire()
    {

        $data['freefire'] = $this->model_kategori->data_freefire()->result();

        $this->load->view('templates/header');
        $this->load->view('templates/sidebar');
        $this->load->view('freefire', $data);
        $this->load->view('templates/footer');
    }

    public function pubg()
    {

        $data['pubg'] = $this->model_kategori->data_pubg()->result();

        $this->load->view('templates/header');
        $this->load->view('templates/sidebar');
        $this->load->view('pubg', $data);
        $this->load->view('templates/footer');
    }

    
}
